exports.mainDetail = (req, res) => {
  res.render("detail");
};
