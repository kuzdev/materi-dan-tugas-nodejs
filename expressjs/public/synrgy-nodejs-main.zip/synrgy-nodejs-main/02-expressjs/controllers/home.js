exports.mainHome = (req, res) => {
  res.render("index");
};
